#!/bin/bash
cd "${0%/*}"


"/opt/homebrew/Cellar/python@3.11/3.11.12/bin/python3.11" "scons-debug.py"
